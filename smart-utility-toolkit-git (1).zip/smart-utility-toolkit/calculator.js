// calculator.js
// A CLI-based calculator using process.argv
// Usage: node calculator.js <operation> <num1> <num2>
// Example: node calculator.js add 10 5

const logger = require("./modules/logger");

// process.argv[0] = node path, [1] = script path, [2+] = actual args
const [, , operation, arg1, arg2] = process.argv;

function showUsageAndExit() {
  console.log("Usage: node calculator.js <add|subtract|multiply|divide> <num1> <num2>");
  console.log("Example: node calculator.js add 10 5");
  process.exit(1);
}

if (!operation || arg1 === undefined || arg2 === undefined) {
  logger.error("Missing arguments.");
  showUsageAndExit();
}

const num1 = Number(arg1);
const num2 = Number(arg2);

if (Number.isNaN(num1) || Number.isNaN(num2)) {
  logger.error(`Invalid numbers provided: "${arg1}", "${arg2}"`);
  showUsageAndExit();
}

let result;

switch (operation.toLowerCase()) {
  case "add":
    result = num1 + num2;
    break;
  case "subtract":
    result = num1 - num2;
    break;
  case "multiply":
    result = num1 * num2;
    break;
  case "divide":
    if (num2 === 0) {
      logger.error("Division by zero is not allowed.");
      process.exit(1);
    }
    result = num1 / num2;
    break;
  default:
    logger.error(`Unknown operation: "${operation}"`);
    showUsageAndExit();
}

logger.info(`Operation: ${operation} | ${num1} , ${num2}`);
console.log(`Result: ${result}`);
