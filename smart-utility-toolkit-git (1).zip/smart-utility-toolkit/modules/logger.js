// modules/logger.js
// A small reusable logging utility with timestamped, leveled console output.

function timestamp() {
  return new Date().toISOString();
}

function info(message) {
  console.log(`[INFO]  [${timestamp()}] ${message}`);
}

function success(message) {
  console.log(`[OK]    [${timestamp()}] ${message}`);
}

function warn(message) {
  console.warn(`[WARN]  [${timestamp()}] ${message}`);
}

function error(message) {
  console.error(`[ERROR] [${timestamp()}] ${message}`);
}

module.exports = { info, success, warn, error };
