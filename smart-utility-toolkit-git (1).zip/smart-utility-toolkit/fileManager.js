// fileManager.js
// A file manager demonstrating CRUD operations with the fs module.
// Run: node fileManager.js

const fs = require("fs");
const logger = require("./modules/logger");

const filePath = "./test.txt";

function createFile() {
  logger.info("Creating File...");
  fs.writeFileSync(filePath, "Hello Node.js\n");
  logger.success("File Created");
}

function readFile() {
  logger.info("Reading File");
  try {
    const data = fs.readFileSync(filePath, "utf8");
    console.log(data.trim());
  } catch (err) {
    logger.error(`Could not read file: ${err.message}`);
  }
}

function updateFile() {
  fs.appendFileSync(filePath, "Learning FS Module\n");
  logger.success("File Updated");
}

function deleteFile() {
  try {
    fs.unlinkSync(filePath);
    logger.success("File Deleted");
  } catch (err) {
    logger.error(`Could not delete file: ${err.message}`);
  }
}

// Demonstrate full CRUD cycle, matching the assignment's sample output
createFile();
readFile();
updateFile();
readFile();
deleteFile();
