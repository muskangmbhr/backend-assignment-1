# Smart Utility Toolkit

Lab Assignment 1 — Web Dev III (Node.js & Express Backend), Unit 1.
Built entirely with Node.js core modules — no external packages.

## Structure

```
smart-utility-toolkit/
├── calculator.js       # CLI calculator (process.argv)
├── app.js              # Demonstrates custom module reuse
├── server.js           # HTTP server with routing
├── fileManager.js       # CRUD file operations (fs)
├── dice.js             # Random dice generator (crypto)
├── test.txt            # Working file used by fileManager.js
├── modules/
│   ├── isEven.js       # Custom module: even/odd check
│   └── logger.js       # Custom module: timestamped logging
└── README.md
```

## How to run each part

### 1. CLI Calculator
```
node calculator.js add 10 5
node calculator.js subtract 10 5
node calculator.js multiply 10 5
node calculator.js divide 10 5
```

### 2. Custom module reuse (isEven + logger)
```
node app.js
```

### 3. HTTP server
```
node server.js
```
Then visit in a browser or Postman:
- http://localhost:3000/
- http://localhost:3000/about
- http://localhost:3000/contact
- any other path → 404

### 4. File manager (fs CRUD)
```
node fileManager.js
```
Creates, reads, updates, reads again, then deletes `test.txt`.

### 5. Dice generator (crypto)
```
node dice.js        # single roll
node dice.js 5       # roll 5 times
```

## Notes

- No external npm packages, Express, or database used — only built-in
  Node.js modules (`process`, `http`, `fs`, `crypto`).
- Error handling included for invalid CLI input, missing files, and
  division by zero.
