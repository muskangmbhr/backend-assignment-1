// dice.js
// A random dice generator using the crypto module for secure randomness.
// Run: node dice.js [numberOfRolls]

const crypto = require("crypto");
const logger = require("./modules/logger");

function rollDice() {
  // crypto.randomInt(min, max) — max is exclusive, so 1-6 needs (1, 7)
  return crypto.randomInt(1, 7);
}

const rolls = Number(process.argv[2]) || 1;

logger.info(`Rolling dice ${rolls} time(s)...`);

for (let i = 1; i <= rolls; i++) {
  const value = rollDice();
  console.log(`🎲 Dice Rolled: ${value}`);
}
