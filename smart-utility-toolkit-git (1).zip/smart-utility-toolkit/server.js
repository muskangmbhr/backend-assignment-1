// server.js
// A basic HTTP server using Node's built-in http module.
// Run: node server.js
// Visit: http://localhost:3000/, /about, /contact

const http = require("http");
const logger = require("./modules/logger");

const PORT = 3000;

const routes = {
  "/": "Welcome to Node Server",
  "/about": "About Page",
  "/contact": "Contact Page",
};

const server = http.createServer((req, res) => {
  logger.info(`${req.method} ${req.url}`);

  const body = routes[req.url];

  if (body) {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end(body);
  } else {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("404 - Page Not Found");
  }
});

server.listen(PORT, () => {
  logger.success(`Server running at http://localhost:${PORT}/`);
});
