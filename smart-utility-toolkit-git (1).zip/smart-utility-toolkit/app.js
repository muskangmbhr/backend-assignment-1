// app.js
// Demonstrates creating and reusing custom modules (isEven, logger)
// Run: node app.js

const isEven = require("./modules/isEven");
const logger = require("./modules/logger");

logger.info("Starting app.js — demonstrating custom module reuse");

const numbersToCheck = [3, 4, 7, 10, 15, 22];

numbersToCheck.forEach((num) => {
  const result = isEven(num) ? "even" : "odd";
  logger.success(`${num} is ${result}`);
});

logger.info("Finished checking numbers.");
